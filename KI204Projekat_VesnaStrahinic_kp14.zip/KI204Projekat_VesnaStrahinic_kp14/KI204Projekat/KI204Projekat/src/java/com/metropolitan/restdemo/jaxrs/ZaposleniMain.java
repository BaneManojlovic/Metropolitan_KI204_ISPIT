
package com.metropolitan.restdemo.jaxrs;

/**
 *
 * @author modes
 */
public class ZaposleniMain {

    public static void main(String[] args) {
        ZaposleniClient myClient = new ZaposleniClient();
        String countREST = myClient.countREST();
        System.out.println("Broj unosa je " + countREST);
    }
}
