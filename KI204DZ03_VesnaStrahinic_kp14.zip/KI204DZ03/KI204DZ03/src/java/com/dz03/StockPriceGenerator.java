package com.dz03;

/**
 *
 * @author modes
 */
import java.util.ArrayList;
import java.util.List;

public class StockPriceGenerator {

    private List<String> supportedSymbols = new ArrayList<>();
    String price;

    public StockPriceGenerator() {
        supportedSymbols.add("AAPL");
        supportedSymbols.add("MSFT");
        supportedSymbols.add("YHOO");
        supportedSymbols.add("AMZN");
        supportedSymbols.add("IBM");
    }

    public String getPrice(String symbol) {

        price = "";

        // Check if the symbol is valid 
        if (supportedSymbols.indexOf(symbol.toUpperCase()) != -1) {

            // Generate a random price for valid symbols
            price = (new Double(Math.random() * 100)).toString();

        } else {
            price = " Sorry! Symbol is not supported. Please use: "
                    + getSupportedSymbols();

        }

        return price;
    }
    
    public double getAmountPrice(double amount){
        
        double amountPrice = 0;
        
        if(amount > 0){
        amountPrice = amount * Double.parseDouble(price);
        } else {
            System.out.println("Amount of stocks must be a positive number!");
        }      
        
    return amountPrice;
    }

    private String getSupportedSymbols() {
        StringBuilder symbols = new StringBuilder();
        for (String symbolName : supportedSymbols) {
            symbols.append(symbolName);
            symbols.append(" ");
        }
        return symbols.toString();
    }
}
