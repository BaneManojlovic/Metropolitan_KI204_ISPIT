package com.dz03;

/**
 *
 * @author modes
 */
import java.io.Serializable;

public class Stock implements Serializable {

    private String symbol;
    private double amount;

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
    
}
