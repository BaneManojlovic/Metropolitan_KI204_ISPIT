package com.dz07.controller;

import com.dz07.model.JmsMsgModel;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Queue;

/**
 *
 * @author modes
 */
@Named
@RequestScoped

public class JmsMsgController {

    @Inject
    private JmsMsgModel jmsMsgModel;

    @Resource(mappedName = "jms/myQueue")
    private Queue myQueue;

    @Inject
    @JMSConnectionFactory("java:comp/DefaultJMSConnectionFactory")
    private JMSContext context;

    public String sendMsg() {
        
        if(jmsMsgModel.getMsgText().equalsIgnoreCase("red")){
        sendJMSMessageToMyQueue(jmsMsgModel.getMsgText());
        return "correctAnswer";
        } else{
        sendJMSMessageToMyQueue(jmsMsgModel.getMsgText());
        }
        return "wrongAnswer";
    }

    private void sendJMSMessageToMyQueue(String messageData) {
        context.createProducer().send(myQueue, messageData);
    }

}
