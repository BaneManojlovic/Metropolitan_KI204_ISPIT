
package ki204ispit.zad2.model;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author modes
 */
@Named
@RequestScoped
public class JmsMsgModel {
    
    private String msgText;

    public String getMsgText() {
        return msgText;
    }

    public void setMsgText(String msgText) {
        this.msgText = msgText;
    }
    
    
}
