package ki204ispit.zad2.controller;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Queue;
import ki204ispit.zad2.model.JmsMsgModel;

/**
 *
 * @author modes
 */
@Named
@RequestScoped
public class JmsMsgController {

    @Inject
    private JmsMsgModel jmsMsgModel;

    @Resource(mappedName = "jms/myMsgQueue")
    private Queue myMsgQueue;

    @Inject
    @JMSConnectionFactory("java:comp/DefaultJMSConnectionFactory")
    private JMSContext context;

    public String sendMsg() {
        int myLenght = jmsMsgModel.getMsgText().length();
        if (myLenght > 8 && myLenght < 18) {
            sendJMSMessageToMyMsgQueue(jmsMsgModel.getMsgText());
            return "confirmation";
        } else {
            sendJMSMessageToMyMsgQueue(jmsMsgModel.getMsgText());
        }
        return "errorMsg";
    }

    private void sendJMSMessageToMyMsgQueue(String messageData) {
        context.createProducer().send(myMsgQueue, messageData);
    }

}
