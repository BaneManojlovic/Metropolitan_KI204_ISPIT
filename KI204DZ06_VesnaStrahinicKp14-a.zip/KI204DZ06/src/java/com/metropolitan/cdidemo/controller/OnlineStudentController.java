
package com.metropolitan.cdidemo.controller;

import com.metropolitan.dz06.students.Student;
import com.metropolitan.dz06.students.OnlineStudent;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import com.metropolitan.dz06.qualifier.Online;
import com.metropolitan.dz06.stereotype.NamedSessionScoped;
import com.metropolitan.dz06.interceptorBinding.LoggingInterceptorBinding;


@LoggingInterceptorBinding
@NamedSessionScoped
public class OnlineStudentController {

    private static final Logger logger = Logger.getLogger(OnlineStudentController.class.getName());
    @Inject
    @Online
    private Student student;

    public String saveStudent() {
        OnlineStudent onlineStudent
                = (OnlineStudent) student;
        logger.log(Level.INFO, "Saving the following information \n"
                + "{0} {1}, courses = {2}",
                new Object[]{onlineStudent.getName(),
                    onlineStudent.getLastName(),
                    onlineStudent.getCourses()});
//If this was a real application, we would have code to save
//customer data to the database here.
        return "online_student_confirm";
    }
}
