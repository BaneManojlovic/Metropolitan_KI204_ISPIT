
package com.metropolitan.cdidemo.controller;

import com.metropolitan.dz06.students.Student;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import com.metropolitan.dz06.stereotype.NamedSessionScoped;


@NamedSessionScoped
public class StudentController {

    @Inject
    private Student student;

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String navigateToConfirmation() {

        return "confirm";
    }
}
