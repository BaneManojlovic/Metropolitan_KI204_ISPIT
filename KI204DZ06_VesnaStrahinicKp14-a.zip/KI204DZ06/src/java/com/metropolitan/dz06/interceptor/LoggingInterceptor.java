
package com.metropolitan.dz06.interceptor;

import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;
import com.metropolitan.dz06.interceptorBinding.LoggingInterceptorBinding;


@LoggingInterceptorBinding
@Interceptor
public class LoggingInterceptor implements Serializable {

    private static final Logger logger = Logger.getLogger(LoggingInterceptor.class.getName());

    @AroundInvoke
    public Object logMethodCall(InvocationContext invocationContext)
            throws Exception {
        logger.log(Level.INFO, new StringBuilder("Input ").append(
                invocationContext.getMethod().getName()).append(
                " methode").toString());
        Object retVal = invocationContext.proceed();
        logger.log(Level.INFO, new StringBuilder("Out ").append(
                invocationContext.getMethod().getName()).append(
                " methode").toString());
        return retVal;
    }

}
