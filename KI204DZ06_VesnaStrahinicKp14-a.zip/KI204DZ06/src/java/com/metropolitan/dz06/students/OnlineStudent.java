package com.metropolitan.dz06.students;

import com.metropolitan.dz06.students.Student;
import com.metropolitan.dz06.qualifier.Online;
import com.metropolitan.dz06.stereotype.NamedSessionScoped;


@NamedSessionScoped
@Online
public class OnlineStudent extends Student {

    private Integer courses;

    public Integer getCourses() {
        return courses;
    }

    public void setCourses(Integer courses) {
        this.courses = courses;
    }
}
