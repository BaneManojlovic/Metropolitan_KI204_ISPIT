package com.dz08.jsonPApiStream;

import com.dz08.jsonpmodelapibean.Osoba;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.json.Json;
import javax.json.stream.JsonGenerator;
import javax.json.stream.JsonParser;

@Named
@RequestScoped
public class JsonPApiStreamBean {

    @Inject
    private Osoba osoba;
    private String jsonStr;

    public String generateJson() {
        StringWriter stringWriter = new StringWriter();
        try (JsonGenerator jsonGenerator
                = Json.createGenerator(stringWriter)) {
            jsonGenerator.writeStartObject().
                    write("indeks", osoba.getIndeks()).
                    write("ime", osoba.getIme()).
                    write("status", osoba.getStatus()).
                    write("tradicionalni", osoba.getTradicionalni()).
                    write("adresa", osoba.getAdresa()).
                    write("telefon", osoba.getTelefon()).
                    write("uloga", osoba.getUloga()).
                    writeEnd();
        }

        setJsonStr(stringWriter.toString());
        return "prikazi_popunjen_obj";
    }

    public String parseJson() {
        StringReader stringReader = new StringReader(jsonStr);

        JsonParser jsonParser = Json.createParser(stringReader);

        Map<String, Object> jsonMap = new HashMap<>();
        String jsonKeyNm = null;
        Object jsonVal = null;

        while (jsonParser.hasNext()) {
            JsonParser.Event event = jsonParser.next();

            if (event.equals(JsonParser.Event.KEY_NAME)) {
                jsonKeyNm = jsonParser.getString();
            } else if (event.equals(JsonParser.Event.VALUE_STRING)) {
                jsonVal = jsonParser.getString();
            } else if (event.equals(JsonParser.Event.VALUE_NUMBER)) {
                jsonVal = jsonParser.getInt();
            }

            jsonMap.put(jsonKeyNm, jsonVal);
        }

        osoba.setIndeks((Integer) jsonMap.get("indeks"));
        osoba.setIme((String) jsonMap.get("ime"));
        osoba.setStatus((String) jsonMap.get("status"));
        osoba.setTradicionalni((Boolean) jsonMap.get("tradicionalni"));
        osoba.setAdresa((String) jsonMap.get("adresa"));
        osoba.setTelefon((Integer) jsonMap.get("telefon"));
        osoba.setUloga((String) jsonMap.get("uloga"));

        return "generisan_json";
    }

    public String getJsonStr() {
        return jsonStr;
    }

    public void setJsonStr(String jsonStr) {
        this.jsonStr = jsonStr;
    }

}
