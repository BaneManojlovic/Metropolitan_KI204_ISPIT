
package com.dz08.jsonpmodelapibean;

import java.io.StringReader;
import java.io.StringWriter;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;

@Named
@RequestScoped
public class JsonPModelApiBean {
    @Inject
    private Osoba osoba;
    private String jsonStr;

    public String generateJson() {
        JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();

        JsonObject jsonObject = jsonObjectBuilder.
                add("broj indeksa", osoba.getIndeks()).
                add("ime i prezime", osoba.getIme()).
                add("status", osoba.getStatus()).
                add("tradicionalni", osoba.getTradicionalni()).
                add("adresa", osoba.getAdresa()).
                add("telefon", osoba.getTelefon()).
                add("uloga", osoba.getUloga()).
                build();

        StringWriter stringWriter = new StringWriter();

        try (JsonWriter jsonWriter = Json.createWriter(stringWriter)) {
            jsonWriter.writeObject(jsonObject);
        }
        setJsonStr(stringWriter.toString());

        return "prikazi_popunjen_obj";
    }

    public String parseJson() {
        JsonObject jsonObject;

        try (JsonReader jsonReader = Json.createReader(new StringReader(jsonStr))) {
            jsonObject = jsonReader.readObject();
        }

        osoba.setIndeks(jsonObject.getInt("broj indeksa"));
        osoba.setIme(jsonObject.getString("ime i prezime"));
        osoba.setStatus(jsonObject.getString("status"));
        osoba.setTradicionalni(jsonObject.getBoolean("tradicionalni"));
        osoba.setAdresa(jsonObject.getString("adresa"));
        osoba.setTelefon(jsonObject.getInt("telefon"));
        osoba.setUloga(jsonObject.getString("uloga"));
        
        return "generisan_json";
    }

    public String getJsonStr() {
        return jsonStr;
    }

    public void setJsonStr(String jsonStr) {
        this.jsonStr = jsonStr;
    }

}
