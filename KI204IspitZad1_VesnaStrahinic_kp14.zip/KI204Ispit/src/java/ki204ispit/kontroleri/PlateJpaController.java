/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ki204ispit.kontroleri;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import ki204ispit.entiteti.Plate;
import ki204ispit.entiteti.PlatePK;
import ki204ispit.entiteti.Zaposleni;
import ki204ispit.kontroleri.exceptions.NonexistentEntityException;
import ki204ispit.kontroleri.exceptions.PreexistingEntityException;
import ki204ispit.kontroleri.exceptions.RollbackFailureException;

/**
 *
 * @author modes
 */
public class PlateJpaController implements Serializable {

    public PlateJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Plate plate) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (plate.getPlatePK() == null) {
            plate.setPlatePK(new PlatePK());
        }
        plate.getPlatePK().setZaposleniBr(plate.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Zaposleni zaposleni = plate.getZaposleni();
            if (zaposleni != null) {
                zaposleni = em.getReference(zaposleni.getClass(), zaposleni.getZaposleniBr());
                plate.setZaposleni(zaposleni);
            }
            em.persist(plate);
            if (zaposleni != null) {
                zaposleni.getPlateCollection().add(plate);
                zaposleni = em.merge(zaposleni);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findPlate(plate.getPlatePK()) != null) {
                throw new PreexistingEntityException("Plate " + plate + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Plate plate) throws NonexistentEntityException, RollbackFailureException, Exception {
        plate.getPlatePK().setZaposleniBr(plate.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Plate persistentPlate = em.find(Plate.class, plate.getPlatePK());
            Zaposleni zaposleniOld = persistentPlate.getZaposleni();
            Zaposleni zaposleniNew = plate.getZaposleni();
            if (zaposleniNew != null) {
                zaposleniNew = em.getReference(zaposleniNew.getClass(), zaposleniNew.getZaposleniBr());
                plate.setZaposleni(zaposleniNew);
            }
            plate = em.merge(plate);
            if (zaposleniOld != null && !zaposleniOld.equals(zaposleniNew)) {
                zaposleniOld.getPlateCollection().remove(plate);
                zaposleniOld = em.merge(zaposleniOld);
            }
            if (zaposleniNew != null && !zaposleniNew.equals(zaposleniOld)) {
                zaposleniNew.getPlateCollection().add(plate);
                zaposleniNew = em.merge(zaposleniNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                PlatePK id = plate.getPlatePK();
                if (findPlate(id) == null) {
                    throw new NonexistentEntityException("The plate with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(PlatePK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Plate plate;
            try {
                plate = em.getReference(Plate.class, id);
                plate.getPlatePK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The plate with id " + id + " no longer exists.", enfe);
            }
            Zaposleni zaposleni = plate.getZaposleni();
            if (zaposleni != null) {
                zaposleni.getPlateCollection().remove(plate);
                zaposleni = em.merge(zaposleni);
            }
            em.remove(plate);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Plate> findPlateEntities() {
        return findPlateEntities(true, -1, -1);
    }

    public List<Plate> findPlateEntities(int maxResults, int firstResult) {
        return findPlateEntities(false, maxResults, firstResult);
    }

    private List<Plate> findPlateEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Plate.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Plate findPlate(PlatePK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Plate.class, id);
        } finally {
            em.close();
        }
    }

    public int getPlateCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Plate> rt = cq.from(Plate.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
