/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ki204ispit.kontroleri;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import ki204ispit.entiteti.Zaposleni;
import ki204ispit.entiteti.Departmani;
import ki204ispit.entiteti.DeptZap;
import ki204ispit.entiteti.DeptZapPK;
import ki204ispit.kontroleri.exceptions.NonexistentEntityException;
import ki204ispit.kontroleri.exceptions.PreexistingEntityException;
import ki204ispit.kontroleri.exceptions.RollbackFailureException;

/**
 *
 * @author modes
 */
public class DeptZapJpaController implements Serializable {

    public DeptZapJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(DeptZap deptZap) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (deptZap.getDeptZapPK() == null) {
            deptZap.setDeptZapPK(new DeptZapPK());
        }
        deptZap.getDeptZapPK().setDeptBr(deptZap.getDepartmani().getDeptBr());
        deptZap.getDeptZapPK().setZaposleniBr(deptZap.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Zaposleni zaposleni = deptZap.getZaposleni();
            if (zaposleni != null) {
                zaposleni = em.getReference(zaposleni.getClass(), zaposleni.getZaposleniBr());
                deptZap.setZaposleni(zaposleni);
            }
            Departmani departmani = deptZap.getDepartmani();
            if (departmani != null) {
                departmani = em.getReference(departmani.getClass(), departmani.getDeptBr());
                deptZap.setDepartmani(departmani);
            }
            em.persist(deptZap);
            if (zaposleni != null) {
                zaposleni.getDeptZapCollection().add(deptZap);
                zaposleni = em.merge(zaposleni);
            }
            if (departmani != null) {
                departmani.getDeptZapCollection().add(deptZap);
                departmani = em.merge(departmani);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findDeptZap(deptZap.getDeptZapPK()) != null) {
                throw new PreexistingEntityException("DeptZap " + deptZap + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(DeptZap deptZap) throws NonexistentEntityException, RollbackFailureException, Exception {
        deptZap.getDeptZapPK().setDeptBr(deptZap.getDepartmani().getDeptBr());
        deptZap.getDeptZapPK().setZaposleniBr(deptZap.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptZap persistentDeptZap = em.find(DeptZap.class, deptZap.getDeptZapPK());
            Zaposleni zaposleniOld = persistentDeptZap.getZaposleni();
            Zaposleni zaposleniNew = deptZap.getZaposleni();
            Departmani departmaniOld = persistentDeptZap.getDepartmani();
            Departmani departmaniNew = deptZap.getDepartmani();
            if (zaposleniNew != null) {
                zaposleniNew = em.getReference(zaposleniNew.getClass(), zaposleniNew.getZaposleniBr());
                deptZap.setZaposleni(zaposleniNew);
            }
            if (departmaniNew != null) {
                departmaniNew = em.getReference(departmaniNew.getClass(), departmaniNew.getDeptBr());
                deptZap.setDepartmani(departmaniNew);
            }
            deptZap = em.merge(deptZap);
            if (zaposleniOld != null && !zaposleniOld.equals(zaposleniNew)) {
                zaposleniOld.getDeptZapCollection().remove(deptZap);
                zaposleniOld = em.merge(zaposleniOld);
            }
            if (zaposleniNew != null && !zaposleniNew.equals(zaposleniOld)) {
                zaposleniNew.getDeptZapCollection().add(deptZap);
                zaposleniNew = em.merge(zaposleniNew);
            }
            if (departmaniOld != null && !departmaniOld.equals(departmaniNew)) {
                departmaniOld.getDeptZapCollection().remove(deptZap);
                departmaniOld = em.merge(departmaniOld);
            }
            if (departmaniNew != null && !departmaniNew.equals(departmaniOld)) {
                departmaniNew.getDeptZapCollection().add(deptZap);
                departmaniNew = em.merge(departmaniNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                DeptZapPK id = deptZap.getDeptZapPK();
                if (findDeptZap(id) == null) {
                    throw new NonexistentEntityException("The deptZap with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(DeptZapPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptZap deptZap;
            try {
                deptZap = em.getReference(DeptZap.class, id);
                deptZap.getDeptZapPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The deptZap with id " + id + " no longer exists.", enfe);
            }
            Zaposleni zaposleni = deptZap.getZaposleni();
            if (zaposleni != null) {
                zaposleni.getDeptZapCollection().remove(deptZap);
                zaposleni = em.merge(zaposleni);
            }
            Departmani departmani = deptZap.getDepartmani();
            if (departmani != null) {
                departmani.getDeptZapCollection().remove(deptZap);
                departmani = em.merge(departmani);
            }
            em.remove(deptZap);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<DeptZap> findDeptZapEntities() {
        return findDeptZapEntities(true, -1, -1);
    }

    public List<DeptZap> findDeptZapEntities(int maxResults, int firstResult) {
        return findDeptZapEntities(false, maxResults, firstResult);
    }

    private List<DeptZap> findDeptZapEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(DeptZap.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public DeptZap findDeptZap(DeptZapPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(DeptZap.class, id);
        } finally {
            em.close();
        }
    }

    public int getDeptZapCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<DeptZap> rt = cq.from(DeptZap.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
