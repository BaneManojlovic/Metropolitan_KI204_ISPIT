/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ki204ispit.kontroleri;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ki204ispit.entiteti.DeptZap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import ki204ispit.entiteti.DeptMenadzer;
import ki204ispit.entiteti.Plate;
import ki204ispit.entiteti.Naslovi;
import ki204ispit.entiteti.Zaposleni;
import ki204ispit.kontroleri.exceptions.IllegalOrphanException;
import ki204ispit.kontroleri.exceptions.NonexistentEntityException;
import ki204ispit.kontroleri.exceptions.PreexistingEntityException;
import ki204ispit.kontroleri.exceptions.RollbackFailureException;

/**
 *
 * @author modes
 */
public class ZaposleniJpaController implements Serializable {

    public ZaposleniJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Zaposleni zaposleni) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (zaposleni.getDeptZapCollection() == null) {
            zaposleni.setDeptZapCollection(new ArrayList<DeptZap>());
        }
        if (zaposleni.getDeptMenadzerCollection() == null) {
            zaposleni.setDeptMenadzerCollection(new ArrayList<DeptMenadzer>());
        }
        if (zaposleni.getPlateCollection() == null) {
            zaposleni.setPlateCollection(new ArrayList<Plate>());
        }
        if (zaposleni.getNasloviCollection() == null) {
            zaposleni.setNasloviCollection(new ArrayList<Naslovi>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<DeptZap> attachedDeptZapCollection = new ArrayList<DeptZap>();
            for (DeptZap deptZapCollectionDeptZapToAttach : zaposleni.getDeptZapCollection()) {
                deptZapCollectionDeptZapToAttach = em.getReference(deptZapCollectionDeptZapToAttach.getClass(), deptZapCollectionDeptZapToAttach.getDeptZapPK());
                attachedDeptZapCollection.add(deptZapCollectionDeptZapToAttach);
            }
            zaposleni.setDeptZapCollection(attachedDeptZapCollection);
            Collection<DeptMenadzer> attachedDeptMenadzerCollection = new ArrayList<DeptMenadzer>();
            for (DeptMenadzer deptMenadzerCollectionDeptMenadzerToAttach : zaposleni.getDeptMenadzerCollection()) {
                deptMenadzerCollectionDeptMenadzerToAttach = em.getReference(deptMenadzerCollectionDeptMenadzerToAttach.getClass(), deptMenadzerCollectionDeptMenadzerToAttach.getDeptMenadzerPK());
                attachedDeptMenadzerCollection.add(deptMenadzerCollectionDeptMenadzerToAttach);
            }
            zaposleni.setDeptMenadzerCollection(attachedDeptMenadzerCollection);
            Collection<Plate> attachedPlateCollection = new ArrayList<Plate>();
            for (Plate plateCollectionPlateToAttach : zaposleni.getPlateCollection()) {
                plateCollectionPlateToAttach = em.getReference(plateCollectionPlateToAttach.getClass(), plateCollectionPlateToAttach.getPlatePK());
                attachedPlateCollection.add(plateCollectionPlateToAttach);
            }
            zaposleni.setPlateCollection(attachedPlateCollection);
            Collection<Naslovi> attachedNasloviCollection = new ArrayList<Naslovi>();
            for (Naslovi nasloviCollectionNasloviToAttach : zaposleni.getNasloviCollection()) {
                nasloviCollectionNasloviToAttach = em.getReference(nasloviCollectionNasloviToAttach.getClass(), nasloviCollectionNasloviToAttach.getNasloviPK());
                attachedNasloviCollection.add(nasloviCollectionNasloviToAttach);
            }
            zaposleni.setNasloviCollection(attachedNasloviCollection);
            em.persist(zaposleni);
            for (DeptZap deptZapCollectionDeptZap : zaposleni.getDeptZapCollection()) {
                Zaposleni oldZaposleniOfDeptZapCollectionDeptZap = deptZapCollectionDeptZap.getZaposleni();
                deptZapCollectionDeptZap.setZaposleni(zaposleni);
                deptZapCollectionDeptZap = em.merge(deptZapCollectionDeptZap);
                if (oldZaposleniOfDeptZapCollectionDeptZap != null) {
                    oldZaposleniOfDeptZapCollectionDeptZap.getDeptZapCollection().remove(deptZapCollectionDeptZap);
                    oldZaposleniOfDeptZapCollectionDeptZap = em.merge(oldZaposleniOfDeptZapCollectionDeptZap);
                }
            }
            for (DeptMenadzer deptMenadzerCollectionDeptMenadzer : zaposleni.getDeptMenadzerCollection()) {
                Zaposleni oldZaposleniOfDeptMenadzerCollectionDeptMenadzer = deptMenadzerCollectionDeptMenadzer.getZaposleni();
                deptMenadzerCollectionDeptMenadzer.setZaposleni(zaposleni);
                deptMenadzerCollectionDeptMenadzer = em.merge(deptMenadzerCollectionDeptMenadzer);
                if (oldZaposleniOfDeptMenadzerCollectionDeptMenadzer != null) {
                    oldZaposleniOfDeptMenadzerCollectionDeptMenadzer.getDeptMenadzerCollection().remove(deptMenadzerCollectionDeptMenadzer);
                    oldZaposleniOfDeptMenadzerCollectionDeptMenadzer = em.merge(oldZaposleniOfDeptMenadzerCollectionDeptMenadzer);
                }
            }
            for (Plate plateCollectionPlate : zaposleni.getPlateCollection()) {
                Zaposleni oldZaposleniOfPlateCollectionPlate = plateCollectionPlate.getZaposleni();
                plateCollectionPlate.setZaposleni(zaposleni);
                plateCollectionPlate = em.merge(plateCollectionPlate);
                if (oldZaposleniOfPlateCollectionPlate != null) {
                    oldZaposleniOfPlateCollectionPlate.getPlateCollection().remove(plateCollectionPlate);
                    oldZaposleniOfPlateCollectionPlate = em.merge(oldZaposleniOfPlateCollectionPlate);
                }
            }
            for (Naslovi nasloviCollectionNaslovi : zaposleni.getNasloviCollection()) {
                Zaposleni oldZaposleniOfNasloviCollectionNaslovi = nasloviCollectionNaslovi.getZaposleni();
                nasloviCollectionNaslovi.setZaposleni(zaposleni);
                nasloviCollectionNaslovi = em.merge(nasloviCollectionNaslovi);
                if (oldZaposleniOfNasloviCollectionNaslovi != null) {
                    oldZaposleniOfNasloviCollectionNaslovi.getNasloviCollection().remove(nasloviCollectionNaslovi);
                    oldZaposleniOfNasloviCollectionNaslovi = em.merge(oldZaposleniOfNasloviCollectionNaslovi);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findZaposleni(zaposleni.getZaposleniBr()) != null) {
                throw new PreexistingEntityException("Zaposleni " + zaposleni + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Zaposleni zaposleni) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Zaposleni persistentZaposleni = em.find(Zaposleni.class, zaposleni.getZaposleniBr());
            Collection<DeptZap> deptZapCollectionOld = persistentZaposleni.getDeptZapCollection();
            Collection<DeptZap> deptZapCollectionNew = zaposleni.getDeptZapCollection();
            Collection<DeptMenadzer> deptMenadzerCollectionOld = persistentZaposleni.getDeptMenadzerCollection();
            Collection<DeptMenadzer> deptMenadzerCollectionNew = zaposleni.getDeptMenadzerCollection();
            Collection<Plate> plateCollectionOld = persistentZaposleni.getPlateCollection();
            Collection<Plate> plateCollectionNew = zaposleni.getPlateCollection();
            Collection<Naslovi> nasloviCollectionOld = persistentZaposleni.getNasloviCollection();
            Collection<Naslovi> nasloviCollectionNew = zaposleni.getNasloviCollection();
            List<String> illegalOrphanMessages = null;
            for (DeptZap deptZapCollectionOldDeptZap : deptZapCollectionOld) {
                if (!deptZapCollectionNew.contains(deptZapCollectionOldDeptZap)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain DeptZap " + deptZapCollectionOldDeptZap + " since its zaposleni field is not nullable.");
                }
            }
            for (DeptMenadzer deptMenadzerCollectionOldDeptMenadzer : deptMenadzerCollectionOld) {
                if (!deptMenadzerCollectionNew.contains(deptMenadzerCollectionOldDeptMenadzer)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain DeptMenadzer " + deptMenadzerCollectionOldDeptMenadzer + " since its zaposleni field is not nullable.");
                }
            }
            for (Plate plateCollectionOldPlate : plateCollectionOld) {
                if (!plateCollectionNew.contains(plateCollectionOldPlate)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Plate " + plateCollectionOldPlate + " since its zaposleni field is not nullable.");
                }
            }
            for (Naslovi nasloviCollectionOldNaslovi : nasloviCollectionOld) {
                if (!nasloviCollectionNew.contains(nasloviCollectionOldNaslovi)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Naslovi " + nasloviCollectionOldNaslovi + " since its zaposleni field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<DeptZap> attachedDeptZapCollectionNew = new ArrayList<DeptZap>();
            for (DeptZap deptZapCollectionNewDeptZapToAttach : deptZapCollectionNew) {
                deptZapCollectionNewDeptZapToAttach = em.getReference(deptZapCollectionNewDeptZapToAttach.getClass(), deptZapCollectionNewDeptZapToAttach.getDeptZapPK());
                attachedDeptZapCollectionNew.add(deptZapCollectionNewDeptZapToAttach);
            }
            deptZapCollectionNew = attachedDeptZapCollectionNew;
            zaposleni.setDeptZapCollection(deptZapCollectionNew);
            Collection<DeptMenadzer> attachedDeptMenadzerCollectionNew = new ArrayList<DeptMenadzer>();
            for (DeptMenadzer deptMenadzerCollectionNewDeptMenadzerToAttach : deptMenadzerCollectionNew) {
                deptMenadzerCollectionNewDeptMenadzerToAttach = em.getReference(deptMenadzerCollectionNewDeptMenadzerToAttach.getClass(), deptMenadzerCollectionNewDeptMenadzerToAttach.getDeptMenadzerPK());
                attachedDeptMenadzerCollectionNew.add(deptMenadzerCollectionNewDeptMenadzerToAttach);
            }
            deptMenadzerCollectionNew = attachedDeptMenadzerCollectionNew;
            zaposleni.setDeptMenadzerCollection(deptMenadzerCollectionNew);
            Collection<Plate> attachedPlateCollectionNew = new ArrayList<Plate>();
            for (Plate plateCollectionNewPlateToAttach : plateCollectionNew) {
                plateCollectionNewPlateToAttach = em.getReference(plateCollectionNewPlateToAttach.getClass(), plateCollectionNewPlateToAttach.getPlatePK());
                attachedPlateCollectionNew.add(plateCollectionNewPlateToAttach);
            }
            plateCollectionNew = attachedPlateCollectionNew;
            zaposleni.setPlateCollection(plateCollectionNew);
            Collection<Naslovi> attachedNasloviCollectionNew = new ArrayList<Naslovi>();
            for (Naslovi nasloviCollectionNewNasloviToAttach : nasloviCollectionNew) {
                nasloviCollectionNewNasloviToAttach = em.getReference(nasloviCollectionNewNasloviToAttach.getClass(), nasloviCollectionNewNasloviToAttach.getNasloviPK());
                attachedNasloviCollectionNew.add(nasloviCollectionNewNasloviToAttach);
            }
            nasloviCollectionNew = attachedNasloviCollectionNew;
            zaposleni.setNasloviCollection(nasloviCollectionNew);
            zaposleni = em.merge(zaposleni);
            for (DeptZap deptZapCollectionNewDeptZap : deptZapCollectionNew) {
                if (!deptZapCollectionOld.contains(deptZapCollectionNewDeptZap)) {
                    Zaposleni oldZaposleniOfDeptZapCollectionNewDeptZap = deptZapCollectionNewDeptZap.getZaposleni();
                    deptZapCollectionNewDeptZap.setZaposleni(zaposleni);
                    deptZapCollectionNewDeptZap = em.merge(deptZapCollectionNewDeptZap);
                    if (oldZaposleniOfDeptZapCollectionNewDeptZap != null && !oldZaposleniOfDeptZapCollectionNewDeptZap.equals(zaposleni)) {
                        oldZaposleniOfDeptZapCollectionNewDeptZap.getDeptZapCollection().remove(deptZapCollectionNewDeptZap);
                        oldZaposleniOfDeptZapCollectionNewDeptZap = em.merge(oldZaposleniOfDeptZapCollectionNewDeptZap);
                    }
                }
            }
            for (DeptMenadzer deptMenadzerCollectionNewDeptMenadzer : deptMenadzerCollectionNew) {
                if (!deptMenadzerCollectionOld.contains(deptMenadzerCollectionNewDeptMenadzer)) {
                    Zaposleni oldZaposleniOfDeptMenadzerCollectionNewDeptMenadzer = deptMenadzerCollectionNewDeptMenadzer.getZaposleni();
                    deptMenadzerCollectionNewDeptMenadzer.setZaposleni(zaposleni);
                    deptMenadzerCollectionNewDeptMenadzer = em.merge(deptMenadzerCollectionNewDeptMenadzer);
                    if (oldZaposleniOfDeptMenadzerCollectionNewDeptMenadzer != null && !oldZaposleniOfDeptMenadzerCollectionNewDeptMenadzer.equals(zaposleni)) {
                        oldZaposleniOfDeptMenadzerCollectionNewDeptMenadzer.getDeptMenadzerCollection().remove(deptMenadzerCollectionNewDeptMenadzer);
                        oldZaposleniOfDeptMenadzerCollectionNewDeptMenadzer = em.merge(oldZaposleniOfDeptMenadzerCollectionNewDeptMenadzer);
                    }
                }
            }
            for (Plate plateCollectionNewPlate : plateCollectionNew) {
                if (!plateCollectionOld.contains(plateCollectionNewPlate)) {
                    Zaposleni oldZaposleniOfPlateCollectionNewPlate = plateCollectionNewPlate.getZaposleni();
                    plateCollectionNewPlate.setZaposleni(zaposleni);
                    plateCollectionNewPlate = em.merge(plateCollectionNewPlate);
                    if (oldZaposleniOfPlateCollectionNewPlate != null && !oldZaposleniOfPlateCollectionNewPlate.equals(zaposleni)) {
                        oldZaposleniOfPlateCollectionNewPlate.getPlateCollection().remove(plateCollectionNewPlate);
                        oldZaposleniOfPlateCollectionNewPlate = em.merge(oldZaposleniOfPlateCollectionNewPlate);
                    }
                }
            }
            for (Naslovi nasloviCollectionNewNaslovi : nasloviCollectionNew) {
                if (!nasloviCollectionOld.contains(nasloviCollectionNewNaslovi)) {
                    Zaposleni oldZaposleniOfNasloviCollectionNewNaslovi = nasloviCollectionNewNaslovi.getZaposleni();
                    nasloviCollectionNewNaslovi.setZaposleni(zaposleni);
                    nasloviCollectionNewNaslovi = em.merge(nasloviCollectionNewNaslovi);
                    if (oldZaposleniOfNasloviCollectionNewNaslovi != null && !oldZaposleniOfNasloviCollectionNewNaslovi.equals(zaposleni)) {
                        oldZaposleniOfNasloviCollectionNewNaslovi.getNasloviCollection().remove(nasloviCollectionNewNaslovi);
                        oldZaposleniOfNasloviCollectionNewNaslovi = em.merge(oldZaposleniOfNasloviCollectionNewNaslovi);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = zaposleni.getZaposleniBr();
                if (findZaposleni(id) == null) {
                    throw new NonexistentEntityException("The zaposleni with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Zaposleni zaposleni;
            try {
                zaposleni = em.getReference(Zaposleni.class, id);
                zaposleni.getZaposleniBr();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The zaposleni with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<DeptZap> deptZapCollectionOrphanCheck = zaposleni.getDeptZapCollection();
            for (DeptZap deptZapCollectionOrphanCheckDeptZap : deptZapCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Zaposleni (" + zaposleni + ") cannot be destroyed since the DeptZap " + deptZapCollectionOrphanCheckDeptZap + " in its deptZapCollection field has a non-nullable zaposleni field.");
            }
            Collection<DeptMenadzer> deptMenadzerCollectionOrphanCheck = zaposleni.getDeptMenadzerCollection();
            for (DeptMenadzer deptMenadzerCollectionOrphanCheckDeptMenadzer : deptMenadzerCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Zaposleni (" + zaposleni + ") cannot be destroyed since the DeptMenadzer " + deptMenadzerCollectionOrphanCheckDeptMenadzer + " in its deptMenadzerCollection field has a non-nullable zaposleni field.");
            }
            Collection<Plate> plateCollectionOrphanCheck = zaposleni.getPlateCollection();
            for (Plate plateCollectionOrphanCheckPlate : plateCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Zaposleni (" + zaposleni + ") cannot be destroyed since the Plate " + plateCollectionOrphanCheckPlate + " in its plateCollection field has a non-nullable zaposleni field.");
            }
            Collection<Naslovi> nasloviCollectionOrphanCheck = zaposleni.getNasloviCollection();
            for (Naslovi nasloviCollectionOrphanCheckNaslovi : nasloviCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Zaposleni (" + zaposleni + ") cannot be destroyed since the Naslovi " + nasloviCollectionOrphanCheckNaslovi + " in its nasloviCollection field has a non-nullable zaposleni field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(zaposleni);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Zaposleni> findZaposleniEntities() {
        return findZaposleniEntities(true, -1, -1);
    }

    public List<Zaposleni> findZaposleniEntities(int maxResults, int firstResult) {
        return findZaposleniEntities(false, maxResults, firstResult);
    }

    private List<Zaposleni> findZaposleniEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Zaposleni.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Zaposleni findZaposleni(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Zaposleni.class, id);
        } finally {
            em.close();
        }
    }

    public int getZaposleniCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Zaposleni> rt = cq.from(Zaposleni.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
