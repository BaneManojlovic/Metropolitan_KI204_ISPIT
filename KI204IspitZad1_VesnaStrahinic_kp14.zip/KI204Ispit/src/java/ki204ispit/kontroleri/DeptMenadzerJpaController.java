/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ki204ispit.kontroleri;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import ki204ispit.entiteti.Zaposleni;
import ki204ispit.entiteti.Departmani;
import ki204ispit.entiteti.DeptMenadzer;
import ki204ispit.entiteti.DeptMenadzerPK;
import ki204ispit.kontroleri.exceptions.NonexistentEntityException;
import ki204ispit.kontroleri.exceptions.PreexistingEntityException;
import ki204ispit.kontroleri.exceptions.RollbackFailureException;

/**
 *
 * @author modes
 */
public class DeptMenadzerJpaController implements Serializable {

    public DeptMenadzerJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(DeptMenadzer deptMenadzer) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (deptMenadzer.getDeptMenadzerPK() == null) {
            deptMenadzer.setDeptMenadzerPK(new DeptMenadzerPK());
        }
        deptMenadzer.getDeptMenadzerPK().setDeptBr(deptMenadzer.getDepartmani().getDeptBr());
        deptMenadzer.getDeptMenadzerPK().setZaposleniBr(deptMenadzer.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Zaposleni zaposleni = deptMenadzer.getZaposleni();
            if (zaposleni != null) {
                zaposleni = em.getReference(zaposleni.getClass(), zaposleni.getZaposleniBr());
                deptMenadzer.setZaposleni(zaposleni);
            }
            Departmani departmani = deptMenadzer.getDepartmani();
            if (departmani != null) {
                departmani = em.getReference(departmani.getClass(), departmani.getDeptBr());
                deptMenadzer.setDepartmani(departmani);
            }
            em.persist(deptMenadzer);
            if (zaposleni != null) {
                zaposleni.getDeptMenadzerCollection().add(deptMenadzer);
                zaposleni = em.merge(zaposleni);
            }
            if (departmani != null) {
                departmani.getDeptMenadzerCollection().add(deptMenadzer);
                departmani = em.merge(departmani);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findDeptMenadzer(deptMenadzer.getDeptMenadzerPK()) != null) {
                throw new PreexistingEntityException("DeptMenadzer " + deptMenadzer + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(DeptMenadzer deptMenadzer) throws NonexistentEntityException, RollbackFailureException, Exception {
        deptMenadzer.getDeptMenadzerPK().setDeptBr(deptMenadzer.getDepartmani().getDeptBr());
        deptMenadzer.getDeptMenadzerPK().setZaposleniBr(deptMenadzer.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptMenadzer persistentDeptMenadzer = em.find(DeptMenadzer.class, deptMenadzer.getDeptMenadzerPK());
            Zaposleni zaposleniOld = persistentDeptMenadzer.getZaposleni();
            Zaposleni zaposleniNew = deptMenadzer.getZaposleni();
            Departmani departmaniOld = persistentDeptMenadzer.getDepartmani();
            Departmani departmaniNew = deptMenadzer.getDepartmani();
            if (zaposleniNew != null) {
                zaposleniNew = em.getReference(zaposleniNew.getClass(), zaposleniNew.getZaposleniBr());
                deptMenadzer.setZaposleni(zaposleniNew);
            }
            if (departmaniNew != null) {
                departmaniNew = em.getReference(departmaniNew.getClass(), departmaniNew.getDeptBr());
                deptMenadzer.setDepartmani(departmaniNew);
            }
            deptMenadzer = em.merge(deptMenadzer);
            if (zaposleniOld != null && !zaposleniOld.equals(zaposleniNew)) {
                zaposleniOld.getDeptMenadzerCollection().remove(deptMenadzer);
                zaposleniOld = em.merge(zaposleniOld);
            }
            if (zaposleniNew != null && !zaposleniNew.equals(zaposleniOld)) {
                zaposleniNew.getDeptMenadzerCollection().add(deptMenadzer);
                zaposleniNew = em.merge(zaposleniNew);
            }
            if (departmaniOld != null && !departmaniOld.equals(departmaniNew)) {
                departmaniOld.getDeptMenadzerCollection().remove(deptMenadzer);
                departmaniOld = em.merge(departmaniOld);
            }
            if (departmaniNew != null && !departmaniNew.equals(departmaniOld)) {
                departmaniNew.getDeptMenadzerCollection().add(deptMenadzer);
                departmaniNew = em.merge(departmaniNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                DeptMenadzerPK id = deptMenadzer.getDeptMenadzerPK();
                if (findDeptMenadzer(id) == null) {
                    throw new NonexistentEntityException("The deptMenadzer with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(DeptMenadzerPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptMenadzer deptMenadzer;
            try {
                deptMenadzer = em.getReference(DeptMenadzer.class, id);
                deptMenadzer.getDeptMenadzerPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The deptMenadzer with id " + id + " no longer exists.", enfe);
            }
            Zaposleni zaposleni = deptMenadzer.getZaposleni();
            if (zaposleni != null) {
                zaposleni.getDeptMenadzerCollection().remove(deptMenadzer);
                zaposleni = em.merge(zaposleni);
            }
            Departmani departmani = deptMenadzer.getDepartmani();
            if (departmani != null) {
                departmani.getDeptMenadzerCollection().remove(deptMenadzer);
                departmani = em.merge(departmani);
            }
            em.remove(deptMenadzer);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<DeptMenadzer> findDeptMenadzerEntities() {
        return findDeptMenadzerEntities(true, -1, -1);
    }

    public List<DeptMenadzer> findDeptMenadzerEntities(int maxResults, int firstResult) {
        return findDeptMenadzerEntities(false, maxResults, firstResult);
    }

    private List<DeptMenadzer> findDeptMenadzerEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(DeptMenadzer.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public DeptMenadzer findDeptMenadzer(DeptMenadzerPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(DeptMenadzer.class, id);
        } finally {
            em.close();
        }
    }

    public int getDeptMenadzerCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<DeptMenadzer> rt = cq.from(DeptMenadzer.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
