/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ki204ispit.kontroleri;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ki204ispit.entiteti.DeptZap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import ki204ispit.entiteti.Departmani;
import ki204ispit.entiteti.DeptMenadzer;
import ki204ispit.kontroleri.exceptions.IllegalOrphanException;
import ki204ispit.kontroleri.exceptions.NonexistentEntityException;
import ki204ispit.kontroleri.exceptions.PreexistingEntityException;
import ki204ispit.kontroleri.exceptions.RollbackFailureException;

/**
 *
 * @author modes
 */
public class DepartmaniJpaController implements Serializable {

    public DepartmaniJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Departmani departmani) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (departmani.getDeptZapCollection() == null) {
            departmani.setDeptZapCollection(new ArrayList<DeptZap>());
        }
        if (departmani.getDeptMenadzerCollection() == null) {
            departmani.setDeptMenadzerCollection(new ArrayList<DeptMenadzer>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<DeptZap> attachedDeptZapCollection = new ArrayList<DeptZap>();
            for (DeptZap deptZapCollectionDeptZapToAttach : departmani.getDeptZapCollection()) {
                deptZapCollectionDeptZapToAttach = em.getReference(deptZapCollectionDeptZapToAttach.getClass(), deptZapCollectionDeptZapToAttach.getDeptZapPK());
                attachedDeptZapCollection.add(deptZapCollectionDeptZapToAttach);
            }
            departmani.setDeptZapCollection(attachedDeptZapCollection);
            Collection<DeptMenadzer> attachedDeptMenadzerCollection = new ArrayList<DeptMenadzer>();
            for (DeptMenadzer deptMenadzerCollectionDeptMenadzerToAttach : departmani.getDeptMenadzerCollection()) {
                deptMenadzerCollectionDeptMenadzerToAttach = em.getReference(deptMenadzerCollectionDeptMenadzerToAttach.getClass(), deptMenadzerCollectionDeptMenadzerToAttach.getDeptMenadzerPK());
                attachedDeptMenadzerCollection.add(deptMenadzerCollectionDeptMenadzerToAttach);
            }
            departmani.setDeptMenadzerCollection(attachedDeptMenadzerCollection);
            em.persist(departmani);
            for (DeptZap deptZapCollectionDeptZap : departmani.getDeptZapCollection()) {
                Departmani oldDepartmaniOfDeptZapCollectionDeptZap = deptZapCollectionDeptZap.getDepartmani();
                deptZapCollectionDeptZap.setDepartmani(departmani);
                deptZapCollectionDeptZap = em.merge(deptZapCollectionDeptZap);
                if (oldDepartmaniOfDeptZapCollectionDeptZap != null) {
                    oldDepartmaniOfDeptZapCollectionDeptZap.getDeptZapCollection().remove(deptZapCollectionDeptZap);
                    oldDepartmaniOfDeptZapCollectionDeptZap = em.merge(oldDepartmaniOfDeptZapCollectionDeptZap);
                }
            }
            for (DeptMenadzer deptMenadzerCollectionDeptMenadzer : departmani.getDeptMenadzerCollection()) {
                Departmani oldDepartmaniOfDeptMenadzerCollectionDeptMenadzer = deptMenadzerCollectionDeptMenadzer.getDepartmani();
                deptMenadzerCollectionDeptMenadzer.setDepartmani(departmani);
                deptMenadzerCollectionDeptMenadzer = em.merge(deptMenadzerCollectionDeptMenadzer);
                if (oldDepartmaniOfDeptMenadzerCollectionDeptMenadzer != null) {
                    oldDepartmaniOfDeptMenadzerCollectionDeptMenadzer.getDeptMenadzerCollection().remove(deptMenadzerCollectionDeptMenadzer);
                    oldDepartmaniOfDeptMenadzerCollectionDeptMenadzer = em.merge(oldDepartmaniOfDeptMenadzerCollectionDeptMenadzer);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findDepartmani(departmani.getDeptBr()) != null) {
                throw new PreexistingEntityException("Departmani " + departmani + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Departmani departmani) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Departmani persistentDepartmani = em.find(Departmani.class, departmani.getDeptBr());
            Collection<DeptZap> deptZapCollectionOld = persistentDepartmani.getDeptZapCollection();
            Collection<DeptZap> deptZapCollectionNew = departmani.getDeptZapCollection();
            Collection<DeptMenadzer> deptMenadzerCollectionOld = persistentDepartmani.getDeptMenadzerCollection();
            Collection<DeptMenadzer> deptMenadzerCollectionNew = departmani.getDeptMenadzerCollection();
            List<String> illegalOrphanMessages = null;
            for (DeptZap deptZapCollectionOldDeptZap : deptZapCollectionOld) {
                if (!deptZapCollectionNew.contains(deptZapCollectionOldDeptZap)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain DeptZap " + deptZapCollectionOldDeptZap + " since its departmani field is not nullable.");
                }
            }
            for (DeptMenadzer deptMenadzerCollectionOldDeptMenadzer : deptMenadzerCollectionOld) {
                if (!deptMenadzerCollectionNew.contains(deptMenadzerCollectionOldDeptMenadzer)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain DeptMenadzer " + deptMenadzerCollectionOldDeptMenadzer + " since its departmani field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<DeptZap> attachedDeptZapCollectionNew = new ArrayList<DeptZap>();
            for (DeptZap deptZapCollectionNewDeptZapToAttach : deptZapCollectionNew) {
                deptZapCollectionNewDeptZapToAttach = em.getReference(deptZapCollectionNewDeptZapToAttach.getClass(), deptZapCollectionNewDeptZapToAttach.getDeptZapPK());
                attachedDeptZapCollectionNew.add(deptZapCollectionNewDeptZapToAttach);
            }
            deptZapCollectionNew = attachedDeptZapCollectionNew;
            departmani.setDeptZapCollection(deptZapCollectionNew);
            Collection<DeptMenadzer> attachedDeptMenadzerCollectionNew = new ArrayList<DeptMenadzer>();
            for (DeptMenadzer deptMenadzerCollectionNewDeptMenadzerToAttach : deptMenadzerCollectionNew) {
                deptMenadzerCollectionNewDeptMenadzerToAttach = em.getReference(deptMenadzerCollectionNewDeptMenadzerToAttach.getClass(), deptMenadzerCollectionNewDeptMenadzerToAttach.getDeptMenadzerPK());
                attachedDeptMenadzerCollectionNew.add(deptMenadzerCollectionNewDeptMenadzerToAttach);
            }
            deptMenadzerCollectionNew = attachedDeptMenadzerCollectionNew;
            departmani.setDeptMenadzerCollection(deptMenadzerCollectionNew);
            departmani = em.merge(departmani);
            for (DeptZap deptZapCollectionNewDeptZap : deptZapCollectionNew) {
                if (!deptZapCollectionOld.contains(deptZapCollectionNewDeptZap)) {
                    Departmani oldDepartmaniOfDeptZapCollectionNewDeptZap = deptZapCollectionNewDeptZap.getDepartmani();
                    deptZapCollectionNewDeptZap.setDepartmani(departmani);
                    deptZapCollectionNewDeptZap = em.merge(deptZapCollectionNewDeptZap);
                    if (oldDepartmaniOfDeptZapCollectionNewDeptZap != null && !oldDepartmaniOfDeptZapCollectionNewDeptZap.equals(departmani)) {
                        oldDepartmaniOfDeptZapCollectionNewDeptZap.getDeptZapCollection().remove(deptZapCollectionNewDeptZap);
                        oldDepartmaniOfDeptZapCollectionNewDeptZap = em.merge(oldDepartmaniOfDeptZapCollectionNewDeptZap);
                    }
                }
            }
            for (DeptMenadzer deptMenadzerCollectionNewDeptMenadzer : deptMenadzerCollectionNew) {
                if (!deptMenadzerCollectionOld.contains(deptMenadzerCollectionNewDeptMenadzer)) {
                    Departmani oldDepartmaniOfDeptMenadzerCollectionNewDeptMenadzer = deptMenadzerCollectionNewDeptMenadzer.getDepartmani();
                    deptMenadzerCollectionNewDeptMenadzer.setDepartmani(departmani);
                    deptMenadzerCollectionNewDeptMenadzer = em.merge(deptMenadzerCollectionNewDeptMenadzer);
                    if (oldDepartmaniOfDeptMenadzerCollectionNewDeptMenadzer != null && !oldDepartmaniOfDeptMenadzerCollectionNewDeptMenadzer.equals(departmani)) {
                        oldDepartmaniOfDeptMenadzerCollectionNewDeptMenadzer.getDeptMenadzerCollection().remove(deptMenadzerCollectionNewDeptMenadzer);
                        oldDepartmaniOfDeptMenadzerCollectionNewDeptMenadzer = em.merge(oldDepartmaniOfDeptMenadzerCollectionNewDeptMenadzer);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = departmani.getDeptBr();
                if (findDepartmani(id) == null) {
                    throw new NonexistentEntityException("The departmani with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Departmani departmani;
            try {
                departmani = em.getReference(Departmani.class, id);
                departmani.getDeptBr();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The departmani with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<DeptZap> deptZapCollectionOrphanCheck = departmani.getDeptZapCollection();
            for (DeptZap deptZapCollectionOrphanCheckDeptZap : deptZapCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Departmani (" + departmani + ") cannot be destroyed since the DeptZap " + deptZapCollectionOrphanCheckDeptZap + " in its deptZapCollection field has a non-nullable departmani field.");
            }
            Collection<DeptMenadzer> deptMenadzerCollectionOrphanCheck = departmani.getDeptMenadzerCollection();
            for (DeptMenadzer deptMenadzerCollectionOrphanCheckDeptMenadzer : deptMenadzerCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Departmani (" + departmani + ") cannot be destroyed since the DeptMenadzer " + deptMenadzerCollectionOrphanCheckDeptMenadzer + " in its deptMenadzerCollection field has a non-nullable departmani field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(departmani);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Departmani> findDepartmaniEntities() {
        return findDepartmaniEntities(true, -1, -1);
    }

    public List<Departmani> findDepartmaniEntities(int maxResults, int firstResult) {
        return findDepartmaniEntities(false, maxResults, firstResult);
    }

    private List<Departmani> findDepartmaniEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Departmani.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Departmani findDepartmani(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Departmani.class, id);
        } finally {
            em.close();
        }
    }

    public int getDepartmaniCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Departmani> rt = cq.from(Departmani.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
