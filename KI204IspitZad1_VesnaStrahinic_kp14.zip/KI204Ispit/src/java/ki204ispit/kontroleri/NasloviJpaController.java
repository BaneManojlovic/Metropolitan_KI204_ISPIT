/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ki204ispit.kontroleri;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import ki204ispit.entiteti.Naslovi;
import ki204ispit.entiteti.NasloviPK;
import ki204ispit.entiteti.Zaposleni;
import ki204ispit.kontroleri.exceptions.NonexistentEntityException;
import ki204ispit.kontroleri.exceptions.PreexistingEntityException;
import ki204ispit.kontroleri.exceptions.RollbackFailureException;

/**
 *
 * @author modes
 */
public class NasloviJpaController implements Serializable {

    public NasloviJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Naslovi naslovi) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (naslovi.getNasloviPK() == null) {
            naslovi.setNasloviPK(new NasloviPK());
        }
        naslovi.getNasloviPK().setZaposleniBr(naslovi.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Zaposleni zaposleni = naslovi.getZaposleni();
            if (zaposleni != null) {
                zaposleni = em.getReference(zaposleni.getClass(), zaposleni.getZaposleniBr());
                naslovi.setZaposleni(zaposleni);
            }
            em.persist(naslovi);
            if (zaposleni != null) {
                zaposleni.getNasloviCollection().add(naslovi);
                zaposleni = em.merge(zaposleni);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findNaslovi(naslovi.getNasloviPK()) != null) {
                throw new PreexistingEntityException("Naslovi " + naslovi + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Naslovi naslovi) throws NonexistentEntityException, RollbackFailureException, Exception {
        naslovi.getNasloviPK().setZaposleniBr(naslovi.getZaposleni().getZaposleniBr());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Naslovi persistentNaslovi = em.find(Naslovi.class, naslovi.getNasloviPK());
            Zaposleni zaposleniOld = persistentNaslovi.getZaposleni();
            Zaposleni zaposleniNew = naslovi.getZaposleni();
            if (zaposleniNew != null) {
                zaposleniNew = em.getReference(zaposleniNew.getClass(), zaposleniNew.getZaposleniBr());
                naslovi.setZaposleni(zaposleniNew);
            }
            naslovi = em.merge(naslovi);
            if (zaposleniOld != null && !zaposleniOld.equals(zaposleniNew)) {
                zaposleniOld.getNasloviCollection().remove(naslovi);
                zaposleniOld = em.merge(zaposleniOld);
            }
            if (zaposleniNew != null && !zaposleniNew.equals(zaposleniOld)) {
                zaposleniNew.getNasloviCollection().add(naslovi);
                zaposleniNew = em.merge(zaposleniNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                NasloviPK id = naslovi.getNasloviPK();
                if (findNaslovi(id) == null) {
                    throw new NonexistentEntityException("The naslovi with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(NasloviPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Naslovi naslovi;
            try {
                naslovi = em.getReference(Naslovi.class, id);
                naslovi.getNasloviPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The naslovi with id " + id + " no longer exists.", enfe);
            }
            Zaposleni zaposleni = naslovi.getZaposleni();
            if (zaposleni != null) {
                zaposleni.getNasloviCollection().remove(naslovi);
                zaposleni = em.merge(zaposleni);
            }
            em.remove(naslovi);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Naslovi> findNasloviEntities() {
        return findNasloviEntities(true, -1, -1);
    }

    public List<Naslovi> findNasloviEntities(int maxResults, int firstResult) {
        return findNasloviEntities(false, maxResults, firstResult);
    }

    private List<Naslovi> findNasloviEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Naslovi.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Naslovi findNaslovi(NasloviPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Naslovi.class, id);
        } finally {
            em.close();
        }
    }

    public int getNasloviCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Naslovi> rt = cq.from(Naslovi.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
